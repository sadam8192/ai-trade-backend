
AI Trade Signals Live Backend (yfinance)
---------------------------------------

This FastAPI app fetches live market data using yfinance and generates trade signals with explanations.

Files:
 - main.py          (FastAPI app)
 - requirements.txt

Run locally (development):
 1. python -m venv venv && source venv/bin/activate
 2. pip install -r requirements.txt
 3. uvicorn main:app --reload --host 0.0.0.0 --port 8000
 4. Call: GET /api/signals?symbols=AAPL,TSLA  with header 'x-api-key: test-api-key'

Deploy to Render:
 - Upload this folder as a ZIP or connect to a GitHub repo. Use a free web service. Render will install requirements and run uvicorn.
