
from fastapi import FastAPI, HTTPException, Query, Header
from typing import List, Optional
import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, timedelta

app = FastAPI(title="AI Trade Signals - Live (yfinance)")

API_KEY = "test-api-key"  # change in production

def ema(series, span):
    return series.ewm(span=span, adjust=False).mean()

def rsi(series, period=14):
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    ma_up = up.rolling(window=period, min_periods=period).mean()
    ma_down = down.rolling(window=period, min_periods=period).mean()
    rs = ma_up / ma_down
    return 100 - (100 / (1 + rs))

def calc_atr(df, period=14):
    high_low = df['High'] - df['Low']
    high_close = (df['High'] - df['Close'].shift()).abs()
    low_close = (df['Low'] - df['Close'].shift()).abs()
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    return tr.rolling(period).mean()

def generate_signals_from_df(df, symbol, ema_short_span=20, ema_long_span=50, rsi_period=14, vol_spike_mult=2.0, breakout_lookback=20):
    df = df.copy().reset_index()
    # expect df has Datetime index or 'Datetime' column; normalize column names
    if 'Datetime' in df.columns:
        df = df.rename(columns={'Datetime':'datetime'})
    # ensure standard column names for calculations
    df = df.rename(columns={c:c.capitalize() for c in df.columns})
    # require Close, High, Low, Volume
    required = {'Close','High','Low','Volume'}
    if not required.issubset(set(df.columns)):
        return []
    df['ema_short'] = ema(df['Close'], ema_short_span)
    df['ema_long'] = ema(df['Close'], ema_long_span)
    df['rsi'] = rsi(df['Close'], rsi_period)
    df['atr'] = calc_atr(df.rename(columns={'High':'High','Low':'Low','Close':'Close'}))
    df['vol_ma_20'] = df['Volume'].rolling(window=20, min_periods=5).mean()
    df['vol_spike'] = df['Volume'] > df['vol_ma_20'] * vol_spike_mult
    df['rolling_high'] = df['High'].rolling(window=breakout_lookback, min_periods=5).max()
    df['rolling_low'] = df['Low'].rolling(window=breakout_lookback, min_periods=5).min()
    df['breakout_up'] = df['Close'] > df['rolling_high']
    df['breakout_down'] = df['Close'] < df['rolling_low']

    signals = []
    for i in range(len(df)):
        row = df.loc[i]
        if pd.isna(row['ema_short']) or pd.isna(row['ema_long']) or pd.isna(row['rsi']) or pd.isna(row['atr']):
            continue
        reasons = []
        score = 0.0
        signal_type = None
        # trend
        if row['ema_short'] > row['ema_long']:
            reasons.append(f"Trend: Short EMA({ema_short_span}) above Long EMA({ema_long_span})")
            score += 0.3
        elif row['ema_short'] < row['ema_long']:
            reasons.append(f"Trend: Short EMA({ema_short_span}) below Long EMA({ema_long_span})")
            score -= 0.3
        # rsi
        if row['rsi'] < 30:
            reasons.append("RSI below 30 (oversold)")
            score += 0.15
        elif row['rsi'] > 70:
            reasons.append("RSI above 70 (overbought)")
            score -= 0.15
        # vol spike
        if row['vol_spike']:
            reasons.append("Volume spike")
            score += 0.25
        # breakout
        if row['breakout_up'] and row['ema_short'] > row['ema_long']:
            reasons.append("Breakout above recent high")
            score += 0.5
            signal_type = "BUY"
        elif row['breakout_down'] and row['ema_short'] < row['ema_long']:
            reasons.append("Breakdown below recent low")
            score -= 0.5
            signal_type = "SELL"
        else:
            if row['ema_short'] > row['ema_long'] and row['rsi'] < 55 and row['Close'] > row['ema_short']:
                signal_type = "BUY"
                reasons.append("Bullish trend with momentum")
                score += 0.1
            elif row['ema_short'] < row['ema_long'] and row['rsi'] > 45 and row['Close'] < row['ema_short']:
                signal_type = "SELL"
                reasons.append("Bearish trend with momentum")
                score -= 0.1
            else:
                continue
        # stop/target using ATR
        atr_val = row['atr'] if row['atr'] > 0 else max(0.01, row['Close'] * 0.005)
        sl_distance = 1.5 * atr_val if ("breakout" in " ".join(reasons).lower()) else 2.0 * atr_val
        if signal_type == "BUY":
            entry = row['Close'] * 1.000
            stop_loss = max(row['Low'], entry - sl_distance)
            rr = 2.0
            target = entry + rr * (entry - stop_loss)
        else:
            entry = row['Close'] * 1.000
            stop_loss = min(row['High'], entry + sl_distance)
            rr = 2.0
            target = entry - rr * (stop_loss - entry)
        confidence = max(0, min(100, (score + 1.0) / 2.0 * 100))
        explanation = " | ".join(reasons) + f". ATR={round(float(atr_val),4)}. RSI={round(float(row['rsi']),2)}."
        signals.append({
            "symbol": symbol,
            "signal": signal_type,
            "entry": round(float(entry), 4),
            "stop_loss": round(float(stop_loss), 4),
            "target": round(float(target), 4),
            "confidence": round(float(confidence),1),
            "explanation": explanation,
            "timestamp": str(row.get('Datetime', row.get('datetime', '')))
        })
    return signals

@app.get("/api/signals")
def get_signals(symbols: Optional[str] = Query("AAPL,MSFT,TSLA"), x_api_key: Optional[str] = Header(None)):
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")
    sym_list = [s.strip().upper() for s in symbols.split(",") if s.strip()]
    result = []
    now = datetime.utcnow()
    # For intraday, try to get 1m or 5m if market open; otherwise get daily
    for sym in sym_list:
        try:
            # try to fetch 120 minutes of 1m data (if available)
            ticker = yf.Ticker(sym)
            # prefer 5m data for reliability across tickers
            df = ticker.history(period="7d", interval="5m")
            if df.empty:
                df = ticker.history(period="60d", interval="1d")
            # Ensure columns: Open, High, Low, Close, Volume
            if df.empty:
                continue
            # reset index to have Datetime column for timestamping
            df = df.reset_index()
            signals = generate_signals_from_df(df, sym)
            if signals:
                # pick the latest signal only
                result.append(signals[-1])
        except Exception as e:
            # skip symbol on error but include error note
            result.append({"symbol": sym, "error": str(e)})
    return {"signals": result, "fetched_at": datetime.utcnow().isoformat()}
